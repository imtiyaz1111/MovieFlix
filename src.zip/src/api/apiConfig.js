const apiConfig = {
  baseUrl: "https://api.themoviedb.org/3/",
  apiKey:
    "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJkZTFjY2MxZjIzZWQ2YTMzYWQ4NmNlZDIzOGMzZTc3MCIsIm5iZiI6MTc0NTEyMzA0NS45MTgwMDAyLCJzdWIiOiI2ODA0NzZlNTAzMzQ0YWVlNzA4OWJmNTkiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.QCu3J1Dv5sbYngPhGD2ETQizTFRQ1dwTVTdz8w_-6ck",
  originalImage: (imgPath) => `https://image.tmdb.org/t/p/original/${imgPath}`,
  w500Image: (imgPath) => `https://image.tmdb.org/t/p/w500/${imgPath}`,
};

export default apiConfig;
